const initialState = {
  city: "Please Select", 
  jobs: []
};

const reducer = (state = initialState, action) => {
  return state; // remove this and fill out the body of the reducer function
};

export default reducer;
