FactoryBot.define do
  factory :user do
    name "MyString"
    password_digest "MyString"
    session_token "MyString"
  end
end
