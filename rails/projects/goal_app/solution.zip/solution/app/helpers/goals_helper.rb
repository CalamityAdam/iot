module GoalsHelper
end
